// API endpoint
const API_URL = 'http://127.0.0.1:5000/api/recommend';

// Validation rules
const VALIDATION_RULES = {
    age: { min: 1, max: 100, required: true },
    bmi: { min: 10, max: 60, required: true },
    bps: { min: 80, max: 200, required: true },
    bsl: { min: 50, max: 400, required: true },
    steps: { min: 0, max: 30000, required: true },
    exercise: { min: 0, max: 7, required: true }
};

// DOM elements
const dietForm = document.getElementById('dietForm');
const submitBtn = document.getElementById('submitBtn');
const spinner = document.getElementById('spinner');
const btnText = submitBtn.querySelector('.btn-text');
const loadingSpinner = document.getElementById('loadingSpinner');
const resultsSection = document.getElementById('resultsSection');
const resultsTableBody = document.getElementById('resultsTableBody');
const profileName = document.getElementById('profileName');
const recommendationType = document.getElementById('recommendationType');
const errorMessage = document.getElementById('errorMessage');
const errorText = document.getElementById('errorText');
const apiErrorAlert = document.getElementById('apiErrorAlert');
const apiErrorText = document.getElementById('apiErrorText');

// Validation functions
function validateField(fieldId, value, rules) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(`${fieldId}-error`);
    
    // Clear previous error
    clearFieldError(fieldId);
    
    // Check if required and empty
    if (rules.required && (value === '' || value === null || value === undefined)) {
        showFieldError(fieldId, 'This field is required');
        return false;
    }
    
    // Skip validation if empty and not required
    if (!rules.required && (value === '' || value === null || value === undefined)) {
        return true;
    }
    
    // Convert to number for numeric validation
    const numValue = Number(value);
    
    // Check if it's a valid number
    if (isNaN(numValue)) {
        showFieldError(fieldId, 'Please enter a valid number');
        return false;
    }
    
    // Check min value
    if (rules.min !== undefined && numValue < rules.min) {
        showFieldError(fieldId, `Value must be at least ${rules.min}`);
        return false;
    }
    
    // Check max value
    if (rules.max !== undefined && numValue > rules.max) {
        showFieldError(fieldId, `Value must be at most ${rules.max}`);
        return false;
    }
    
    return true;
}

function showFieldError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(`${fieldId}-error`);
    
    if (field && errorElement) {
        field.classList.add('error');
        errorElement.textContent = message;
    }
}

function clearFieldError(fieldId) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(`${fieldId}-error`);
    
    if (field && errorElement) {
        field.classList.remove('error');
        errorElement.textContent = '';
    }
}

function validateForm() {
    let isValid = true;
    
    // Validate numeric fields
    isValid = validateField('age', document.querySelector('#age').value, VALIDATION_RULES.age) && isValid;
    isValid = validateField('bmi', document.querySelector('#bmi').value, VALIDATION_RULES.bmi) && isValid;
    isValid = validateField('bps', document.querySelector('#bps').value, VALIDATION_RULES.bps) && isValid;
    isValid = validateField('bsl', document.querySelector('#bsl').value, VALIDATION_RULES.bsl) && isValid;
    isValid = validateField('steps', document.querySelector('#steps').value, VALIDATION_RULES.steps) && isValid;
    isValid = validateField('exercise', document.querySelector('#exercise').value, VALIDATION_RULES.exercise) && isValid;
    
    // Validate select fields
    const chronic = document.querySelector('#chronic').value;
    if (!chronic) {
        showFieldError('chronic', 'Please select an option');
        isValid = false;
    } else {
        clearFieldError('chronic');
    }
    
    const alcohol = document.querySelector('#alcohol').value;
    if (!alcohol) {
        showFieldError('alcohol', 'Please select an option');
        isValid = false;
    } else {
        clearFieldError('alcohol');
    }
    
    const smoking = document.querySelector('#smoking').value;
    if (!smoking) {
        showFieldError('smoking', 'Please select an option');
        isValid = false;
    } else {
        clearFieldError('smoking');
    }
    
    const diet = document.querySelector('#diet').value;
    if (!diet) {
        showFieldError('diet', 'Please select an option');
        isValid = false;
    } else {
        clearFieldError('diet');
    }
    
    return isValid;
}

// Add real-time validation on input
document.querySelectorAll('input[type="number"], select').forEach(field => {
    field.addEventListener('blur', () => {
        const fieldId = field.id;
        if (VALIDATION_RULES[fieldId]) {
            validateField(fieldId, field.value, VALIDATION_RULES[fieldId]);
        }
    });
    
    field.addEventListener('input', () => {
        const fieldId = field.id;
        if (VALIDATION_RULES[fieldId]) {
            // Clear error on input if value is valid
            const rules = VALIDATION_RULES[fieldId];
            const value = field.value;
            const numValue = Number(value);
            
            if (value && !isNaN(numValue) && 
                (rules.min === undefined || numValue >= rules.min) &&
                (rules.max === undefined || numValue <= rules.max)) {
                clearFieldError(fieldId);
            }
        }
    });
});

// Handle form submission
dietForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Hide previous results and errors
    resultsSection.style.display = 'none';
    errorMessage.style.display = 'none';
    apiErrorAlert.style.display = 'none';
    
    // Validate form before submission
    if (!validateForm()) {
        // Scroll to first error
        const firstError = document.querySelector('.error');
        if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
            firstError.focus();
        }
        return;
    }
    
    // Build payload with exact backend keys
    const payload = {
        Age: Number(document.querySelector('#age').value),
        BMI: Number(document.querySelector('#bmi').value),
        Chronic_Disease: document.querySelector('#chronic').value,
        Blood_Pressure_Systolic: Number(document.querySelector('#bps').value),
        Blood_Sugar_Level: Number(document.querySelector('#bsl').value),
        Daily_Steps: Number(document.querySelector('#steps').value),
        Exercise_Frequency: Number(document.querySelector('#exercise').value),
        Alcohol_Consumption: document.querySelector('#alcohol').value,
        Smoking_Habit: document.querySelector('#smoking').value,
        Dietary_Habits: document.querySelector('#diet').value,
    };
    
    // Show loading state
    setLoadingState(true);
    
    try {
        // Send POST request to API
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload)
        });
        
        // Check if response is ok
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({ error: `HTTP error! status: ${response.status}` }));
            const errorMessage = errorData.error || `Server error (${response.status})`;
            
            // Show API error at top for 400/500 errors
            if (response.status === 400 || response.status === 500) {
                showApiError(errorMessage);
            } else {
                displayError(errorMessage);
            }
            // Don't return here - let finally block run to re-enable button
        } else {
            // Parse response
            const result = await response.json();
            
            // Display results
            displayResults(result);
        }
        
    } catch (error) {
        console.error('Error:', error);
        // Network errors or other issues
        showApiError(error.message || 'An error occurred while fetching recommendations. Please check your connection and try again.');
    } finally {
        // Hide loading state
        setLoadingState(false);
    }
});

// Set loading state
function setLoadingState(isLoading) {
    if (isLoading) {
        submitBtn.disabled = true;
        btnText.textContent = 'Processing...';
        spinner.style.display = 'inline-block';
        loadingSpinner.style.display = 'block';
    } else {
        submitBtn.disabled = false;
        btnText.textContent = 'Get Recommendations';
        spinner.style.display = 'none';
        loadingSpinner.style.display = 'none';
    }
}

// Display results
function displayResults(result) {
    // Set profile name and recommendation type
    profileName.textContent = result.profile_name || 'Profile';
    recommendationType.textContent = result.recommendation_type || '';
    
    // Clear previous table rows
    resultsTableBody.innerHTML = '';
    
    // Check if there are recommended foods
    if (!result.recommended_foods || result.recommended_foods.length === 0) {
        resultsTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 40px;">No recommendations available.</td></tr>';
    } else {
        // Add each food to the table
        result.recommended_foods.forEach(food => {
            const row = document.createElement('tr');
            
            row.innerHTML = `
                <td><strong>${escapeHtml(food.Food || 'N/A')}</strong></td>
                <td>${escapeHtml(food.Category || 'N/A')}</td>
                <td>${formatNumber(food.Protein)}</td>
                <td>${formatNumber(food.Fat)}</td>
                <td>${formatNumber(food.Carbs)}</td>
                <td><strong>${formatNumber(food.Calories)}</strong></td>
            `;
            
            resultsTableBody.appendChild(row);
        });
    }
    
    // Show results section
    resultsSection.style.display = 'block';
    
    // Scroll to results
    resultsSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Display error message (for general errors)
function displayError(message) {
    errorText.textContent = message;
    errorMessage.style.display = 'block';
    
    // Scroll to error
    errorMessage.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Show API error at top (for 400/500 errors)
function showApiError(message) {
    apiErrorText.textContent = message;
    apiErrorAlert.style.display = 'block';
    
    // Scroll to top to show error
    apiErrorAlert.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Format number (handle NaN and null)
function formatNumber(value) {
    if (value === null || value === undefined || isNaN(value)) {
        return '0';
    }
    return Number(value).toFixed(1);
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

